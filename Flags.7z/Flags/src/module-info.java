module flags {
	exports flags;

	requires java.desktop;
	requires org.apache.commons.lang3;
}