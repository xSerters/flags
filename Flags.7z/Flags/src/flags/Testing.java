package flags;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Testing {

	public static BufferedImage resizeImage() throws IOException {

		int targetWidth = 64;
		int targetHeight = 64;

		BufferedImage read = ImageIO.read(new File("original.png"));
		BufferedImage originalImage = ImageIO.read(new File("original.png"));

		Image resultingImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_DEFAULT);
		BufferedImage outputImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
		outputImage.getGraphics().drawImage(resultingImage, 0, 0, null);
		return outputImage;

	}
	


	public static void printImage(BufferedImage Image) {

		BufferedImage read = Image;
		String[] coatOfArms = new String[read.getHeight() / 2];
		System.out.println(read.getHeight());
		// String coatOfArmsLine = "";
		for (int i = 0; i < read.getHeight(); i += 2) {
			for (int j = 0; j < read.getWidth(); j++) {
				int pixel = read.getRGB(j, i);
				int a = pixel >> 24 & 0xFF;
				char c = a == 255 ? 'u' : '█';
				System.out.print(c);
			}

			System.out.print("\n");
		}

	}

}
