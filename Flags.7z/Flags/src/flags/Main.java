package flags;

import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {

		//Scanner scan = new Scanner(System.in);
		//int flagWidth = Utilities.widthUserInput(scan);
		
		//CoatOfArms coa = new CoatOfArms(flagWidth);
		//Flag.displayFlag(coa.getCoatOfArms(), flagWidth);
		
		Testing.printImage(Testing.resizeImage());
		
	}

}
