package flags;

import org.apache.commons.lang3.StringUtils;

public class Flag {

	// public Flag(String[] coatOfArms, int flagWidth) {

	// }

	public static void displayFlag(String[] coatOfArms, int flagWidth) {

		int flagHeight = flagWidth / 3 * 2;
		int coatOfArmsHeight = coatOfArms.length;
		int nonCoatOfArmsRows = (flagHeight - coatOfArmsHeight) / 2;
		int leftPadding = flagWidth / 5;
		int rightPadding = flagWidth * 2;
		int rowIndex = 0;
		String flagLine = StringUtils.center("█", flagWidth * 2, '█');

		System.out.println(Utilities.serbiaBlue + "Flag Height: " + flagHeight);
		System.out.println(Utilities.serbiaWhite + "Coat Of Arms Resolution: " + coatOfArms.length * 2 + "px");
		System.out.println(Utilities.serbiaGrayCoA);

		for (int i = 0; i < flagHeight; i++) {

			if (rowIndex < (flagHeight / 3)) {
				System.out.print(Utilities.serbiaRed);
			} else if (rowIndex >= (flagHeight / 3) && rowIndex < (2 * flagHeight / 3)) {
				System.out.print(Utilities.serbiaBlue);
			} else {
				System.out.print(Utilities.serbiaWhite);
			}

			rowIndex++;

			if (i <= nonCoatOfArmsRows || i > flagHeight - nonCoatOfArmsRows) {
				System.out.println(flagLine);
			} else {
				String coatOfArmsLine = coatOfArms[i - nonCoatOfArmsRows - 1];
				coatOfArmsLine = StringUtils.leftPad(coatOfArmsLine, leftPadding + (coatOfArmsHeight * 2), "█");
				coatOfArmsLine = StringUtils.rightPad(coatOfArmsLine, rightPadding, "█");
				System.out.println(coatOfArmsLine);
			}
		}
	}

}
