package flags;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.StringUtils;

public class Backup {

	public String coatOfArmsResolution(int flagWidth) {

		int flagHeight = flagWidth / 3 * 4;
		int imageResolution = 0;
		int[] imageResolutions = new int[] { 16, 32, 64, 128 };

		for (int i = 0; i < imageResolutions.length; i++) {

			if (imageResolutions[i] <= flagHeight) {
				imageResolution = imageResolutions[i];
			}
		}
		return Integer.toString(imageResolution);
	}

	public String createEagle(String eagleResolutionInput) throws IOException {

		String eagleResolution = eagleResolutionInput + ".png";
		String eagleResolutionPng = eagleResolution;
		String eagle = "";

		BufferedImage read = ImageIO.read(new File(eagleResolutionPng));
		for (int i = 0; i < read.getHeight(); i += 2) {
			for (int j = 0; j < read.getWidth(); j++) {
				int pixel = read.getRGB(j, i);
				int a = pixel >> 24 & 0xFF;
				char c = a == 255 ? ' ' : '█'; // ░
				eagle += c;
			}
			eagle += "\n";
		}
		return eagle;
	}

	public String[] createCoatofArms(int flagWidth) throws IOException {

		String coatOfArmsResolution = coatOfArmsResolution(flagWidth);
		int coatOfArmsHeight = Integer.valueOf(coatOfArmsResolution);
		String eagle = createEagle(coatOfArmsResolution);

		String[] coatOfArms = new String[coatOfArmsHeight / 2];
		String[] eagleSplit = eagle.split("\n");

		for (int i = 0; i < eagleSplit.length; i++) {
			coatOfArms[i] = eagleSplit[i];
		}
		return coatOfArms;
	}
	// flag

	public void flagRowColor(int rowIndex, int flagHeight) {

		if (rowIndex < (flagHeight / 3)) {
			System.out.print(FlagColors.serbiaRed);
		} else if (rowIndex >= (flagHeight / 3) && rowIndex < (2 * flagHeight / 3)) {
			System.out.print(FlagColors.serbiaBlue);
		} else {
			System.out.print(FlagColors.serbiaWhite);
		}

	}

	public void displayFlag(String[] coatOfArms, int flagWidth) {

		int flagHeight = flagWidth / 3 * 2;
		int coatOfArmsHeight = coatOfArms.length;
		int nonCoatOfArmsRows = (flagHeight - coatOfArmsHeight) / 2;
		int leftPadding = flagWidth / 5;
		int rightPadding = flagWidth * 2;
		int rowIndex = 0;
		String flagLine = StringUtils.center("█", flagWidth * 2, '█');

		System.out.println(FlagColors.serbiaBlue + "Flag Height: " + flagHeight);
		System.out.println(FlagColors.serbiaWhite + "Coat Of Arms Resolution: " + coatOfArms.length * 2 + "px");
		System.out.println(FlagColors.serbiaGrayCoA);

		for (int i = 0; i < flagHeight; i++) {
			flagRowColor(rowIndex, flagHeight);
			rowIndex++;
			if (i <= nonCoatOfArmsRows || i > flagHeight - nonCoatOfArmsRows) {
				System.out.println(flagLine);
			} else {
				String coatOfArmsLine = coatOfArms[i - nonCoatOfArmsRows - 1];
				coatOfArmsLine = StringUtils.leftPad(coatOfArmsLine, leftPadding + (coatOfArmsHeight * 2), "█");
				coatOfArmsLine = StringUtils.rightPad(coatOfArmsLine, rightPadding, "█");
				System.out.println(coatOfArmsLine);
			}
		}
	}

	public int widthUserInput(Scanner scan) {

		System.out.print(Utilities.bgBlack + Utilities.serbiaRed + "Flag width: ");
		int flagWidth = scan.nextInt();
		return flagWidth;

	}

}
