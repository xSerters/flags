package flags;

import java.util.Scanner;

public class Utilities {
	
	public static final String serbiaBlue = "\u001b[38;2;15;71;175m";
	public static final String serbiaRed = "\u001b[38;2;217;30;24m";
	public static final String serbiaWhite = "\u001b[37m";
	public static final String serbiaWhiteCoA = "\u001b[47m";
	public static final String serbiaGrayCoA = "\u001b[48;2;186;186;186m";
	public static final String bgBlack = "\u001b[40m";
	
	public static int widthUserInput(Scanner scan) {

		System.out.print(Utilities.bgBlack + Utilities.serbiaRed + "Flag width: ");
		int flagWidth = scan.nextInt();
		return flagWidth;

	}

}