package flags;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class CoatOfArms {

	private String[] coatOfArms;

	public CoatOfArms(int flagWidth) throws IOException {
		coatOfArms = createCoatofArms(flagWidth);
	}

	public String[] getCoatOfArms() {
		return coatOfArms;
	}

	private String[] createCoatofArms(int flagWidth) throws IOException {

		int flagHeight = flagWidth / 3 * 2;
		int[] imageResolutions = new int[] { 16, 32, 64, 128 };
		String imageResolution = "";

		for (int i = 0; i < imageResolutions.length; i++) {
			if (imageResolutions[i] <= (flagHeight * 2)) {
				imageResolution = imageResolutions[i] + ".png";
			}
		}

		BufferedImage read = ImageIO.read(new File(imageResolution));
		String[] coatOfArms = new String[read.getHeight() / 2];
		String coatOfArmsLine = "";
		for (int i = 0; i < read.getHeight(); i += 2) {
			for (int j = 0; j < read.getWidth(); j++) {
				int pixel = read.getRGB(j, i);
				int a = pixel >> 24 & 0xFF;
				char c = a == 255 ? ' ' : '█';
				coatOfArmsLine += c;
			}
			coatOfArms[i / 2] = coatOfArmsLine;
			coatOfArmsLine = "";
		}

		return coatOfArms;
	}
	
	

}